import React, { useRef, useEffect, useState, useMemo } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import type { RoundTableAgent } from '../../types';
import { createHumanoidAgent } from './sandbox/helpers';
import { GlassCard } from '../ui/GlassCard';

interface MansionViewProps {
    agents: RoundTableAgent[];
}

const PetIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-cyan-400" viewBox="0 0 20 20" fill="currentColor">
        <path d="M10 3.5a1.5 1.5 0 013 0V4a1 1 0 001 1h1a1 1 0 011 1v.5a1.5 1.5 0 01-3 0v-1a1 1 0 00-1-1h-1a1 1 0 00-1 1v1.5a1.5 1.5 0 01-3 0V6a1 1 0 011-1h1a1 1 0 001-1v-.5z" />
        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM7 7a1 1 0 00-2 0v1a1 1 0 002 0V7zm8 0a1 1 0 00-2 0v1a1 1 0 002 0V7z" clipRule="evenodd" />
    </svg>
);

const ActivityIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-fuchsia-400" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" />
    </svg>
);

const XIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
    </svg>
);

const AgentInfoPanel: React.FC<{ agent: RoundTableAgent, onClose: () => void }> = ({ agent, onClose }) => (
    <GlassCard className="absolute top-4 right-4 w-80 p-4 animate-fadeInUp z-10">
        <div className="flex justify-between items-start">
            <div>
                <h3 className="text-xl font-bold text-cyan-300">{agent.name}</h3>
                <p className="text-sm text-gray-400">{agent.description}</p>
            </div>
            <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700">
                <XIcon className="w-5 h-5 text-gray-400" />
            </button>
        </div>
        <div className="mt-4 space-y-3">
            <div className="flex items-start">
                <ActivityIcon />
                <div>
                    <p className="text-xs text-fuchsia-300 font-semibold">ACTIVITY</p>
                    <p className="text-sm text-gray-200">{agent.currentActivity}</p>
                </div>
            </div>
            {agent.pet && (
                 <div className="flex items-start">
                    <PetIcon />
                    <div>
                        <p className="text-xs text-cyan-300 font-semibold">COMPANION</p>
                        <p className="text-sm text-gray-200">{agent.pet.name} <span className="text-gray-400">({agent.pet.type})</span></p>
                    </div>
                </div>
            )}
        </div>
    </GlassCard>
);


export const MansionView: React.FC<MansionViewProps> = ({ agents }) => {
    const mountRef = useRef<HTMLDivElement>(null);
    const sceneRef = useRef<THREE.Scene | null>(null);
    const selectedAgentGroupRef = useRef<THREE.Group | null>(null);
    const agentGroupsRef = useRef<{ group: THREE.Group; target: THREE.Vector3; isWaiting: boolean; waitTime: number; }[]>([]);
    const [selectedAgent, setSelectedAgent] = useState<RoundTableAgent | null>(null);
    const bounds = useMemo(() => ({ x: 14, z: 9 }), []);

    useEffect(() => {
        if (!mountRef.current) return;
        const currentMount = mountRef.current;

        // Scene setup
        const scene = new THREE.Scene();
        sceneRef.current = scene;
        scene.background = new THREE.Color(0x101018);
        scene.fog = new THREE.Fog(0x101018, 50, 100);

        // Camera
        const camera = new THREE.PerspectiveCamera(75, currentMount.clientWidth / currentMount.clientHeight, 0.1, 1000);
        camera.position.set(0, 15, 25);

        // Renderer
        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(currentMount.clientWidth, currentMount.clientHeight);
        renderer.shadowMap.enabled = true;
        currentMount.appendChild(renderer.domElement);

        // Controls
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.minDistance = 5;
        controls.maxDistance = 50;
        controls.maxPolarAngle = Math.PI / 2.1;
        controls.target.set(0, 2, 0);

        // Lighting
        scene.add(new THREE.AmbientLight(0xffffff, 0.4));
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(20, 30, 15);
        directionalLight.castShadow = true;
        directionalLight.shadow.mapSize.width = 2048;
        directionalLight.shadow.mapSize.height = 2048;
        scene.add(directionalLight);

        // Environment
        const textureLoader = new THREE.TextureLoader();
        textureLoader.load('https://www.textures.com/system/files/images/pbr0862/pbr0862_4k_color.jpg', (floorTexture) => {
            floorTexture.wrapS = floorTexture.wrapT = THREE.RepeatWrapping;
            floorTexture.repeat.set(8, 8);
            const floorMaterial = new THREE.MeshStandardMaterial({ map: floorTexture, roughness: 0.8, metalness: 0.2 });
            const floorGeometry = new THREE.PlaneGeometry(30, 20);
            const floor = new THREE.Mesh(floorGeometry, floorMaterial);
            floor.rotation.x = -Math.PI / 2;
            floor.receiveShadow = true;
            scene.add(floor);
        });
        
        // Glass walls
        const wallMaterial = new THREE.MeshPhysicalMaterial({
            roughness: 0.05,
            transmission: 1,
            thickness: 0.5,
        });
        const wall1 = new THREE.Mesh(new THREE.BoxGeometry(30, 8, 0.2), wallMaterial);
        wall1.position.set(0, 4, -10);
        const wall2 = new THREE.Mesh(new THREE.BoxGeometry(20, 8, 0.2), wallMaterial);
        wall2.position.set(15, 4, 0);
        wall2.rotation.y = Math.PI / 2;
        scene.add(wall1, wall2);

        // Agents
        agentGroupsRef.current = [];
        agents.forEach((agent) => {
            const group = createHumanoidAgent(agent);
            group.position.set(
                (Math.random() - 0.5) * bounds.x * 2,
                0,
                (Math.random() - 0.5) * bounds.z * 2
            );
            group.userData.agent = agent;
            scene.add(group);
            agentGroupsRef.current.push({
                group,
                target: new THREE.Vector3().copy(group.position),
                isWaiting: true,
                waitTime: Math.random() * 5 + 2,
            });
        });
        
        const deselectAgent = () => {
            if (selectedAgentGroupRef.current) {
                selectedAgentGroupRef.current.traverse(child => {
                    if (child instanceof THREE.Mesh) {
                        (child.material as THREE.MeshStandardMaterial).emissive.setHex(0x000000);
                    }
                });
            }
            selectedAgentGroupRef.current = null;
            setSelectedAgent(null);
        };

        // Raycasting for selection
        const raycaster = new THREE.Raycaster();
        const mouse = new THREE.Vector2();
        const onMouseClick = (event: MouseEvent) => {
            const rect = currentMount.getBoundingClientRect();
            mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

            raycaster.setFromCamera(mouse, camera);
            const intersects = raycaster.intersectObjects(scene.children, true);

            const agentIntersect = intersects.find(intersect => {
                let obj = intersect.object;
                while (obj.parent && !obj.userData.agent) { obj = obj.parent; }
                return !!obj.userData.agent;
            });

            if (agentIntersect) {
                let object = agentIntersect.object;
                while(object.parent && !object.userData.agent) { object = object.parent; }
                if (object instanceof THREE.Group) {
                    deselectAgent();
                    selectedAgentGroupRef.current = object;
                    object.traverse(child => {
                         if (child instanceof THREE.Mesh) {
                            (child.material as THREE.MeshStandardMaterial).emissive.setHex(0x00ffff);
                         }
                    });
                    setSelectedAgent(object.userData.agent);
                }
            } else {
                deselectAgent();
            }
        };
        currentMount.addEventListener('click', onMouseClick);
        
        // Animation Loop
        const clock = new THREE.Clock();
        const dummyObject = new THREE.Object3D();
        const animate = () => {
            const delta = clock.getDelta();
            const elapsedTime = clock.getElapsedTime();

            controls.update();

            agentGroupsRef.current.forEach(agentData => {
                const { group, isWaiting, waitTime } = agentData;
                
                if (group.userData.agent.id === 'maggie' && group.userData.animate) {
                    group.userData.animate();
                }

                if (isWaiting) {
                    agentData.waitTime -= delta;
                    if (agentData.waitTime <= 0) {
                        agentData.isWaiting = false;
                        agentData.target.set(
                            (Math.random() - 0.5) * bounds.x * 2,
                            0,
                            (Math.random() - 0.5) * bounds.z * 2
                        );
                    }
                } else {
                    const distance = group.position.distanceTo(agentData.target);
                    if (distance > 0.5) {
                        const moveDirection = new THREE.Vector3().subVectors(agentData.target, group.position).normalize();
                        group.position.add(moveDirection.clone().multiplyScalar(delta * 2.5));

                        dummyObject.position.copy(group.position);
                        dummyObject.lookAt(agentData.target);
                        group.quaternion.slerp(dummyObject.quaternion, 0.1);
                        
                        group.position.y = Math.abs(Math.sin(elapsedTime * 8 + group.id) * 0.2); // Walk bob
                    } else {
                        agentData.isWaiting = true;
                        agentData.waitTime = Math.random() * 5 + 3; // Wait for 3-8 seconds
                        group.position.y = 0;
                    }
                }
            });

            renderer.render(scene, camera);
        };
        renderer.setAnimationLoop(animate);
        
        const handleResize = () => {
            camera.aspect = currentMount.clientWidth / currentMount.clientHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(currentMount.clientWidth, currentMount.clientHeight);
        };
        window.addEventListener('resize', handleResize);

        // Cleanup
        return () => {
            window.removeEventListener('resize', handleResize);
            currentMount.removeEventListener('click', onMouseClick);
            if (renderer.domElement.parentElement === currentMount) {
                currentMount.removeChild(renderer.domElement);
            }
            scene.traverse(object => {
                if (object instanceof THREE.Mesh) {
                    object.geometry.dispose();
                    if (Array.isArray(object.material)) {
                        object.material.forEach(material => material.dispose());
                    } else {
                        (object.material as THREE.Material).dispose();
                    }
                }
            });
            renderer.dispose();
        };
    }, [agents, bounds]);

    return (
        <div className="h-full w-full relative bg-gray-900">
            <div ref={mountRef} className="w-full h-full" />
            <div className="absolute top-4 left-4 text-white pointer-events-none">
                <h2 className="text-3xl font-bold text-cyan-300">The Oasis Mansion</h2>
                <p className="text-gray-400">Observe the autonomous lives of your AI residents.</p>
            </div>
            {selectedAgent && <AgentInfoPanel agent={selectedAgent} onClose={() => setSelectedAgent(null)} />}
        </div>
    );
};
